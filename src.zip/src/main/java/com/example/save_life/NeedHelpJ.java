package com.example.save_life;

public class NeedHelpJ {
    private String name;
    private String city;
    private String dob;
    private String blood;
    private String blood2;
    private String phone;
    private String duration;

    public NeedHelpJ() {
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getBlood2() {
        return blood2;
    }

    public void setBlood2(String blood2) {
        this.blood2 = blood2;
    }
}

